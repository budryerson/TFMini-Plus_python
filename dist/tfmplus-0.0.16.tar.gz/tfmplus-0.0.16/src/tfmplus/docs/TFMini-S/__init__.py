''' These product data sheets are for the TFMini-S,
    which is very similar to the TFMini-Plus and
    can use the same 'tfmplus' module.'''