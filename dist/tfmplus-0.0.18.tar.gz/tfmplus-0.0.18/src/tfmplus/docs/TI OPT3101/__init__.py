''' These data sheets help explain the internal
    TI chip that is the heart of the device.'''